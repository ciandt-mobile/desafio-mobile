package com.example.movies.src.view;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movies.R;
import com.example.movies.src.model.MovieBean;
import com.example.movies.src.model.PersonBean;
import com.example.movies.src.utils.Logger;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.squareup.picasso.Picasso;

import java.util.List;

public class DetailedMovieView extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener {
    private static final String TAG = "DetailedMovieView";

    MovieBean movie;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detailed_movie);

        movie = new MovieBean(new Gson().fromJson(getIntent().getStringExtra("movie"), JsonObject.class),
                new Gson().fromJson(getIntent().getStringExtra("config"), JsonObject.class));
        movie.setDetailedMovieInfo(new Gson().fromJson(getIntent().getStringExtra("movie"), JsonObject.class));

        YouTubePlayerView youTubeView = (YouTubePlayerView) findViewById(R.id.videoView);
        if (movie.getVideoKey() != null) {
            youTubeView.initialize(PlayerConfig.API_KEY, this);
        } else {
            findViewById(R.id.videoViewLayout).setVisibility(View.GONE);
        }

        ImageView originalImage = findViewById(R.id.originalImage);
        Logger.log(TAG, movie.getOriginalPosterURL());
        Picasso.get().load(movie.getOriginalPosterURL()).into(originalImage);

        TextView movieName = findViewById(R.id.detailedMovieName);
        movieName.setText(movie.getName());

        TextView movieYear = findViewById(R.id.detailedMovieYear);
        movieYear.setText(movie.getMovieYear());

        TextView movieOverview = findViewById(R.id.detailedMovieOverview);
        movieOverview.setText(movie.getMovieOverview());

        TextView movieGenres = findViewById(R.id.detailedMovieGenres);
        movieGenres.setText(movie.getRunTime() + "  " + getString(R.string.minutes) + " | " + movie.getGenresNames());

        new CastAdapter(this.getApplicationContext(), movie.getCast());


    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean wasRestored) {
        if (!wasRestored) {
            youTubePlayer.cueVideo(movie.getVideoKey());
        }
    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

    }

    private class PlayerConfig {
        PlayerConfig(){}
        public static final String API_KEY = "AIzaSyDCvd7fQIT5CL_AYTWeFTFGdcuh2IaHp_c";
    }

    /*private class CastAdapter extends BaseAdapter {
        private Activity activity;
        private List<PersonBean> cast;
        private static final String TAG = "CastAdapter";

        public CastAdapter(Activity a, List<PersonBean> cast) {
            activity = a;
            this.cast = cast;

            GridView rootLayout = (GridView) activity.findViewById(R.id.detailedMovieCast);
            //rootLayout.setNumColumns(getCount());
            rootLayout.setAdapter(this);

        }
        public int getCount() {
            return cast.size();
        }
        public Object getItem(int position) {
            return position;
        }
        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {

            CastViewHolder holder = null;
            if (convertView == null) {
                holder = new CastViewHolder();
                convertView = LayoutInflater.from(activity).inflate(R.layout.movie_cast, parent, false);

                holder.castImg = (ImageView) convertView.findViewById(R.id.movieCastImg);
                holder.castName = (TextView) convertView.findViewById(R.id.personName);
                holder.castCharacter = (TextView) convertView.findViewById(R.id.personCharacter);

                convertView.setTag(holder);
            } else {
                holder = (CastViewHolder) convertView.getTag();
            }
            holder.castImg.setId(position);
            holder.castName.setId(position);
            holder.castCharacter.setId(position);

            final PersonBean person = cast.get(position);
            try {
                holder.castName.setText(person.getName());
                holder.castCharacter.setText(person.getCharacter());
                Logger.log(TAG, "position: " + position + " " + person.getImgRUL());

                Picasso.get().load(person.getImgRUL()).into(holder.castImg);


            } catch (Exception e) {}
            return convertView;
        }

        class CastViewHolder {
            ImageView castImg;
            TextView castName, castCharacter;
        }
    }*/

    private class CastAdapter extends RecyclerView.Adapter<CastAdapter.CastViewHolder> {

        private LayoutInflater mInflater;
        private List<PersonBean> mCast;
        private static final String TAG = "CastAdapter";

        // data is passed into the constructor
        public CastAdapter(Context context, List<PersonBean> cast) {
            this.mInflater = LayoutInflater.from(context);
            this.mCast = cast;
        }

        // inflates the row layout from xml when needed
        @Override
        public CastViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = mInflater.inflate(R.layout.movie_cast, parent, false);
            return new CastViewHolder(view);
        }

        // binds the data to the TextView in each row
        @Override
        public void onBindViewHolder(CastViewHolder holder, int position) {
            PersonBean person = mCast.get(position);
            holder.castName.setText(person.getName());
            holder.castCharacter.setText(person.getCharacter());
            Picasso.get().load(person.getImgRUL()).into(holder.castImg);
        }

        // total number of rows
        @Override
        public int getItemCount() {
            return mCast.size();
        }

        class CastViewHolder extends RecyclerView.ViewHolder {
            ImageView castImg;
            TextView castName, castCharacter;

            public CastViewHolder(@NonNull View itemView) {
                super(itemView);
            }
        }
    }
}
